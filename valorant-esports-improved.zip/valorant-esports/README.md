# VALORANT Champions Tracker

A static Champions Shanghai 2026 dashboard with schedules, GSL groups,
standings, an editable double-elimination playoff bracket, local Pick’Em
predictions, and an optional Twitch player/chat.

Based on [jasoonl/valorant-esports](https://github.com/jasoonl/valorant-esports).
The application is still entirely contained in **`index.html`**. It needs no
build step, framework, account, or package installation to run.

## Use the update

Replace your existing `index.html` with this version. The remaining files are
documentation and developer checks; they are not required for hosting.

For local use, serve the folder:

```sh
python3 -m http.server 8000
```

Open **http://localhost:8000**. On Windows, `py -m http.server 8000` also works.
You can also upload `index.html` to your existing static hosting service.
Opening the file directly supports the tracker, but the Twitch embed requires
a web address and browser persistence may vary for local files.

Existing picks/results from the previous version are migrated on the same
browser and origin. To move to another browser or domain, use **Backup** and
**Restore**. Backups remain local downloads; there is no account sync.

## What changed

- **Correct bracket propagation.** Results are bound to both participating
  teams. Changing a prior winner or playoff slot removes incompatible later
  results, including scores whose winning team happens to remain the same.
- **Trustworthy live labels.** Only a recent, matched Riot response can mark
  a series LIVE. A passed scheduled start is labelled Awaiting update.
- **Protected edits.** Manual final scores, map scores, and cleared matches
  are not overwritten by auto-sync. Open a manually edited match and select
  **Use feed** to release that override. Sync is for group matches only.
- **Safer feed handling.** Impossible scores, unknown states, missing scores,
  fuzzy team-name matches, and unrelated dates are rejected. Duplicate schedule
  and live responses cannot downgrade a final. Polling backs off on errors and
  pauses in hidden tabs or while offline.
- **A more useful schedule.** Search team names/codes, filter groups and status,
  follow teams, choose a time zone, and export future filtered matches as `.ics`.
- **Spoiler control.** Hide scores, qualification status, derived matchups,
  bracket views, and Pick’Em outcome feedback until you choose to reveal them.
- **Portable data.** Export and restore a validated JSON backup of your picks,
  results, playoff slots, followed teams, preferences, and checklist.
- **Better Twitch behavior.** Load the stream when requested, keep the video
  running when toggling chat, and stop the embed when hiding the stream. Small
  screens get a direct Twitch link instead of an undersized player.
- **More usable controls.** Keyboard tab navigation, visible focus, labelled
  dialogs, scrolling tables/brackets on mobile, useful empty states, and a
  visible warning when browser storage cannot save your data.
- **Safer reset.** Resetting results keeps your Pick’Em selections and preferences.

## Data and limitations

The original repository's **September 30, 2026 snapshot** is preserved. The
bundled teams, scores, start times, and playoff date notes are not a continuously
maintained schedule. Result labels distinguish the snapshot, Riot sync, and
local edits. Confirm dates, the official draw, and results on the
[official bracket](https://valorantesports.com/en-SG/tournament/115576361459045501).

Riot sync uses the original site's public-feed integration on a best-effort
basis. The provider, browser CORS rules, or your network can prevent access.
The tracker remains usable with saved data and manual scores. This update does
not supply a backend, promise live availability, or automatically populate the
official playoff draw. Match reconciliation is limited to the 20 bundled group
fixtures and checks exact team identities plus proximity to the scheduled time.

Calendar downloads contain future, uncompleted group fixtures matching your
filters. Events are tentative, use UTC timestamps, and have an explicitly
estimated three-hour duration. Importing a calendar does not subscribe it to
future changes; export again if the schedule changes.

Pick’Em selections here are editable personal predictions; they are not official
submissions and are not locked at match start. Submit official picks on Riot's
site. The visible-page timer does not measure Twitch playback or drop progress;
check [Twitch inventory](https://www.twitch.tv/drops/inventory) for rewards.

## Checks

Node.js 20+ runs the dependency-free engine suite:

```sh
npm test
```

The tests execute the engine from `index.html`, including all 1,024 complete GSL
outcome combinations, score validation, downstream invalidation, safe sync,
legacy storage, backup round trips, filters, time zones, and calendar output.

Optional browser checks use Playwright:

```sh
npm install --no-save playwright
npx playwright install chromium
npm run test:browser
```

The browser script starts and closes its own local server. It checks all six
views, result editing, persistence, keyboard navigation, filters, backups,
calendar downloads, spoiler hiding, stream lifecycle, storage failures, and
320px/390px layouts. It writes screenshots to `test-results/`.

Browser checks **stub external Riot/Twitch responses** to stay deterministic;
they do not verify real broadcast playback, Twitch login, drops, or current
production-feed availability. `CHROMIUM_EXECUTABLE_PATH` can select an existing
Chromium executable when the default Playwright browser is unavailable.

See `VERIFICATION.md` for the checks performed on this update.
