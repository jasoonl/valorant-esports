# Implementation notes — September 30, 2026

The original single-file design and six tournament views are preserved.

Completed:

- Bind each result to its participants and reconcile dependent rounds in order.
- Validate stored scores, picks, slots, preferences, and restored backups.
- Migrate legacy browser data to the versioned `vct26:tracker` envelope.
- Distinguish bundled snapshots, manual overrides, and feed-confirmed data.
- Require a fresh feed response for LIVE; expire stale statuses.
- Protect manual overrides, completed results, and open result editors from sync.
- Add filters, followed teams, time zones, calendar export, and spoiler hiding.
- Add backup/restore and preserve picks when resetting results.
- Keep Twitch optional and avoid reloading the player when chat changes.
- Add focused engine regression checks and browser interaction/layout checks.

Scope retained: the inherited snapshot and bracket topology are not a new
verified tournament dataset. Official playoff seeding remains manual. There
is no Riot account integration, Twitch rewards integration, or hosted backend.
