# Verification

Base: `jasoonl/valorant-esports`, commit `c5882a9`.
Update checked on September 30, 2026.

- `npm test`: 16 passing tests, including exhaustive evaluation of 1,024
  complete GSL result combinations.
- `npm run test:browser`: Chromium interaction checks for all six tabs, saving
  and editing scores, reload persistence, keyboard navigation, safe result
  reset, Pick’Em selection limits, spoiler hiding, combined schedule filters,
  followed teams, time-zone display, actual JSON/calendar downloads, backup
  restoration, invalid backup rejection, Twitch iframe lifecycle, mocked Riot
  sync, unavailable browser storage, and 320px/390px mobile layouts.
- Desktop and mobile screenshots visually inspected. Tables and playoff
  brackets scroll within their cards; opening the mobile stream uses a direct
  Twitch fallback and does not widen the page.
- Inline JavaScript syntax check and `git diff --check`.

External Riot/Twitch responses are stubbed in browser tests. Live upstream
availability, real Twitch playback, account login, and rewards are not covered.
The repository's bundled tournament snapshot has been retained, not refreshed
or independently reverified match by match.

Runtime used: Node.js 24.19.0, Playwright 1.62.1, Chromium 153.
The app itself does not require Node.js or Playwright to run.
