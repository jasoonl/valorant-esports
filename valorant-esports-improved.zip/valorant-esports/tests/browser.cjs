const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const http = require('node:http');
let chromium;
try { ({chromium}=require('playwright')); }
catch { ({chromium}=require(path.join(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES || '', 'playwright'))); }

const html=fs.readFileSync(path.join(__dirname,'..','index.html'));
const output=path.join(__dirname,'..','test-results');
fs.mkdirSync(output,{recursive:true});
const errors=[];
const server=http.createServer((req,res)=>{
  if(req.url==='/favicon.ico'){res.writeHead(204);res.end();return;}
  res.writeHead(200,{'Content-Type':'text/html; charset=utf-8'});res.end(html);
});

(async()=>{
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const url=`http://localhost:${server.address().port}`;
  const browser=await chromium.launch({headless:true,
    ...(process.env.CHROMIUM_EXECUTABLE_PATH?{executablePath:process.env.CHROMIUM_EXECUTABLE_PATH}:{}),
    args:['--no-sandbox','--disable-dev-shm-usage']});
  try{
    const ctx=await browser.newContext({viewport:{width:1440,height:1000},timezoneId:'America/New_York'});
    await ctx.addInitScript(()=>{
      window.__vctNow=Date.parse('2026-09-30T14:00:00Z');
      if(localStorage.getItem('vct26:syncOn')===null)localStorage.setItem('vct26:syncOn','false');
    });
    let feed=[];
    await ctx.route('**/*',route=>{
      const u=new URL(route.request().url());
      if(u.hostname==='localhost')return route.continue();
      if(u.hostname==='esports-api.service.valorantesports.com')return route.fulfill({json:{data:{schedule:{events:feed}}}});
      return route.fulfill({contentType:'text/html',body:'<!doctype html><title>External embed stub</title>'});
    });
    const page=await ctx.newPage();page.on('pageerror',e=>errors.push(e.message));
    await page.goto(url);await page.waitForFunction(()=>!!window.__vct);
    assert.match(await page.locator('#filterCount').innerText(),/20 of 20/);
    assert.equal(await page.locator('#stage').isVisible(),false);
    assert.equal(await page.locator('.badge.live:visible').count(),0);
    await page.screenshot({path:path.join(output,'desktop.png'),fullPage:true});

    // Every view renders and uses proper tab state.
    for(const tab of ['groups','standings','playoffs','pickem','rewards','schedule']){
      await page.locator(`[data-tab="${tab}"]`).click();
      assert.equal(await page.locator('#pane-'+tab).isVisible(),true);
      assert.ok((await page.locator('#pane-'+tab).innerText()).length>30);
    }
    await page.locator('#tab-schedule').focus();await page.keyboard.press('ArrowRight');
    assert.equal(await page.locator('#tab-groups').getAttribute('aria-selected'),'true');
    await page.keyboard.press('End');assert.equal(await page.locator('#tab-rewards').getAttribute('aria-selected'),'true');

    // Picking a third team never silently replaces an existing choice.
    await page.locator('[data-tab="pickem"]').click();
    for(const t of ['100T','FUT','T1'])await page.locator(`[data-focus-key="pick-A-${t}"]`).click();
    assert.deepEqual(await page.evaluate(()=>window.__vct.state.picks.adv.A),['100T','FUT']);
    await page.locator('#championPick').selectOption('PRX');

    // Change an opening winner through the actual editor and reload.
    await page.locator('[data-tab="groups"]').click();
    await page.locator('[data-focus-key="match-TYL-G2"]').click();
    await page.locator('#dlg .opts').first().getByRole('button',{name:'TYL TYLOO',exact:true}).click();
    await page.locator('#dlg').getByRole('button',{name:'2-0',exact:true}).click();
    await page.locator('#dlg').getByRole('button',{name:'Save result',exact:true}).click();
    assert.equal(await page.evaluate(()=>window.__vct.state.results['C-W']),undefined);
    await page.reload();await page.waitForFunction(()=>!!window.__vct);
    assert.equal(await page.evaluate(()=>window.__vct.state.results['C-O2'].w),'TYL');
    page.once('dialog',d=>d.accept());await page.locator('#resetAll').click();
    assert.deepEqual(await page.evaluate(()=>window.__vct.state.picks.adv.A),['100T','FUT']);
    assert.equal(await page.evaluate(()=>window.__vct.state.results['C-W'].w),'PRX');

    // Score and advancement spoilers disappear across views.
    await page.locator('#spoilerToggle').click();
    assert.match(await page.locator('#pane-groups').innerText(),/Spoilers are hidden/i);
    await page.locator('[data-tab="pickem"]').click();
    assert.equal(await page.locator('#pane-pickem .pick.correct').count(),0);
    assert.equal(await page.locator('#pane-pickem .pick.wrong').count(),0);
    await page.locator('[data-tab="schedule"]').click();
    assert.match(await page.locator('[data-match="C-W"]').innerText(),/Hidden/);
    await page.locator('#spoilerToggle').click();

    await page.locator('#matchSearch').fill('paper rex');
    assert.match(await page.locator('#filterCount').innerText(),/2 of 20/);
    await page.locator('#groupFilter').selectOption('A');
    assert.match(await page.locator('#pane-schedule').innerText(),/No matches match/);
    await page.locator('#clearFilters').click();
    await page.locator('#followTeams').click();
    await page.locator('#dlg').getByRole('button',{name:'PRX Paper Rex',exact:true}).click();
    await page.locator('#dlg').getByRole('button',{name:'Done',exact:true}).click();
    await page.locator('#favoritesOnly').click();
    assert.match(await page.locator('#filterCount').innerText(),/2 of 20/);
    await page.locator('#clearFilters').click();await page.locator('#timezone').selectOption('Asia/Shanghai');
    assert.match(await page.locator('[data-match="C-E"] .tm').innerText(),/5:00 PM|17:00/);

    // Real downloads and restore through the file picker.
    const download1=page.waitForEvent('download');await page.locator('#exportBackup').click();
    const backup=JSON.parse(fs.readFileSync(await (await download1).path(),'utf8'));
    assert.equal(backup.state.picks.champ,'PRX');
    await page.evaluate(()=>{window.__vct.state.picks.champ='NRG';window.__vct.commit();});
    page.once('dialog',d=>d.accept());
    await page.locator('#backupFile').setInputFiles({name:'backup.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify(backup))});
    await page.waitForFunction(()=>window.__vct.state.picks.champ==='PRX');
    await page.locator('#backupFile').setInputFiles({name:'bad.json',mimeType:'application/json',buffer:Buffer.from('{}')});
    await page.waitForFunction(()=>document.querySelector('#toast').textContent.includes('version 1 backup'));
    const download2=page.waitForEvent('download');await page.locator('#calendarExport').click();
    const calendar=fs.readFileSync(await (await download2).path(),'utf8');
    assert.equal((calendar.match(/BEGIN:VEVENT/g)||[]).length,8);

    // Stream stays on the same iframe when chat changes, and unloads on close.
    await page.locator('#streamToggle').click();
    assert.match(await page.locator('#player iframe').getAttribute('src'),/parent=localhost/);
    await page.locator('#player iframe').evaluate(el=>el.dataset.testIdentity='keep');
    await page.locator('#chatToggle').click();
    assert.equal(await page.locator('#player iframe').getAttribute('data-test-identity'),'keep');
    await page.locator('#streamToggle').click();assert.equal(await page.locator('#player iframe').count(),0);

    // Exercise runSync with controlled responses, including manual protection.
    feed=[{startTime:'2026-09-30T12:00:00Z',state:'inProgress',match:{teams:[{code:'100T',result:{gameWins:1}},{code:'FUT',result:{gameWins:0}}]}}];
    await page.locator('#retrySync').click();await page.waitForFunction(()=>window.__vct.sync.status==='ok'&&!window.__vct.sync.busy);
    assert.match(await page.locator('#pillLive').innerText(),/1 live match/);
    await page.evaluate(()=>{const a=window.__vct;a.setGroupResult('A-W',['100T','FUT'],{w:'FUT',s:[2,1]});a.commit();});
    feed[0].state='completed';feed[0].match.teams[0].result.gameWins=2;
    await page.locator('#retrySync').click();await page.waitForFunction(()=>!window.__vct.sync.busy);
    assert.equal(await page.evaluate(()=>window.__vct.state.results['A-W'].w),'FUT');
    await page.locator('#pillSync').click();assert.equal(await page.evaluate(()=>window.__vct.sync.on),false);

    // Narrow layouts scroll tables/brackets within their cards, never the page.
    for(const width of [390,320]){
      await page.setViewportSize({width,height:844});
      for(const tab of ['schedule','groups','standings','playoffs','pickem','rewards']){
        await page.locator(`[data-tab="${tab}"]`).click();
        const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1);
        assert.equal(overflow,false,`${width}px ${tab} overflows`);
      }
    }
    await page.setViewportSize({width:390,height:844});await page.locator('[data-tab="schedule"]').click();
    await page.screenshot({path:path.join(output,'mobile.png'),fullPage:true});
    await page.locator('#streamToggle').click();assert.equal(await page.locator('#player iframe').count(),0);
    assert.match(await page.locator('#player').innerText(),/Open Twitch/);
    assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth+1),false,'mobile stream overflows');

    const broken=await browser.newContext();
    await broken.addInitScript(()=>{
      localStorage.setItem('vct26:syncOn','false');
      localStorage.setItem('vct26:tracker',JSON.stringify({version:1,state:{tab:'wrong',picks:null,po:[],results:'bad',channel:7}}));
      Storage.prototype.setItem=function(){throw new DOMException('Blocked','SecurityError');};
    });
    const blockedPage=await broken.newPage();blockedPage.on('pageerror',e=>errors.push(e.message));
    await blockedPage.goto(url);await blockedPage.waitForFunction(()=>!!window.__vct);
    assert.match(await blockedPage.locator('#dataNote').innerText(),/storage is unavailable/);
    assert.deepEqual(errors,[]);
    console.log('Browser checks passed: all views, editing, persistence, tabs, filters, spoilers, backup/restore, calendar, stream lifecycle, mocked sync, storage failures, 390px/320px layouts.');
  } finally {await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1;}).finally(()=>server.close());
