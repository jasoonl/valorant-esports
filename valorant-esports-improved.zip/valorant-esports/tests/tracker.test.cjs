const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');

// Exercise the actual inline engine; no duplicate implementation or build step.
const html = fs.readFileSync(path.join(__dirname, '..', 'index.html'), 'utf8');
const script = html.match(/<script>([\s\S]*?)<\/script>/)[1];
function between(start, end) { return script.slice(script.indexOf(start), script.indexOf(end)); }
function engine(saved = {}) {
  const storage = new Map(Object.entries(saved).map(([k,v]) => ['vct26:'+k,JSON.stringify(v)]));
  const context = vm.createContext({
    window: { __vctNow: Date.parse('2026-09-30T14:00:00Z') }, TextEncoder, URL,
    localStorage: { getItem:k=>storage.get(k) ?? null, setItem:(k,v)=>storage.set(k,v) }
  });
  const src = [
    between('/* ---------- static data', '/* ---------- dialogs'),
    between('/* ---------- Schedule / live', '/* ---------- Auto-sync'),
    between('const RIOT_API', 'async function riotGet'),
    between('function backupPayload', 'function syncFilterControls'),
    'globalThis.api={state,SEED,GROUPS,PO,POBY,allQualified,resolveGroup,groupStandings,validRes,normalizeState,reconcileState,setGroupResult,poTeams,poOutcome,matchStatus,allMatches,normEvent,applyEvents,sync,filteredMatches,buildCalendar,parseBackup,backupPayload,save,dayKey,dayLabel,timeLabel,liveScore};'
  ].join('\n');
  vm.runInContext(src, context);
  return context.api;
}
const plain = x => JSON.parse(JSON.stringify(x));
function event(codes, wins, state='completed', start='2026-09-30T12:00:00Z') {
  return { codes, wins, state, start:new Date(start) };
}
function completeGroups(a) {
  for (const g of Object.keys(a.GROUPS)) for (const k of ['O1','O2','W','E','D']) {
    const m = a.resolveGroup(g)[k];
    if (!a.state.results[m.id]) a.setGroupResult(m.id,m.teams,{w:m.teams[0],s:[2,0]});
  }
}

test('bundled results resolve to three qualifiers without inventing remaining matches', () => {
  const a=engine();
  assert.deepEqual(plain(a.allQualified()).sort(),['NRG','PRX','VIT']);
  assert.equal(a.allMatches().length,20);
  assert.deepEqual(plain(a.resolveGroup('A').W.teams),['100T','FUT']);
  assert.equal(a.state.results['C-W'].source,'seed');
});

test('series validation rejects ties, partial scores, impossible scores and foreign participants', () => {
  const a=engine();
  for (const s of [[2,2],[1,0],[3,0],[2,-1],[2,1.5],['2',0],[2],[2,0,0]])
    assert.equal(a.validRes({w:'PRX',s},['PRX','G2']),false,JSON.stringify(s));
  assert.equal(a.validRes({w:'PRX',s:[2,0]},['PRX','PRX']),false);
  assert.equal(a.validRes({w:'NRG',s:[2,0]},['PRX','G2']),false);
  assert.equal(a.validRes({w:'PRX',s:[2,0],teams:['PRX','TL']},['PRX','G2']),false);
  assert.equal(a.validRes({w:'PRX',s:[3,2]},['PRX','G2'],5),true);
});

test('changing an opening opponent invalidates later result even if its winner is unchanged', () => {
  const a=engine();
  a.setGroupResult('C-E',['TL','TYL'],{w:'TL',s:[2,1]});
  a.setGroupResult('C-D',['G2','TL'],{w:'G2',s:[2,0]});
  a.state.po.assign={U1a:'PRX',U1b:'NRG'};
  a.state.po.results.U1={w:'NRG',s:[2,0],teams:['PRX','NRG']};
  const removed=a.setGroupResult('C-O2',['TYL','G2'],{w:'TYL',s:[2,0]});
  assert.ok(removed>=4);
  for(const id of ['C-W','C-E','C-D']) assert.equal(a.state.results[id],undefined,id);
  assert.equal(a.state.manual['C-E'],undefined);
  assert.equal(a.state.po.results.U1,undefined);
  assert.equal(a.state.po.assign.U1a,undefined);
});

test('editing only a score preserves valid downstream results', () => {
  const a=engine();
  assert.equal(a.setGroupResult('C-O2',['TYL','G2'],{w:'G2',s:[2,1]}),0);
  assert.equal(a.state.results['C-W'].w,'PRX');
});

test('all 1,024 complete GSL outcomes produce two qualifiers and balanced totals', () => {
  const a=engine(), keys=['O1','O2','W','E','D'];
  for(let scenario=0;scenario<1024;scenario++){
    const results={};let n=scenario;
    for(const key of keys){
      const m=a.resolveGroup('A',results)[key], option=n%4;n=Math.floor(n/4);
      results[m.id]={w:m.teams[Math.floor(option/2)],s:[2,option%2],teams:plain(m.teams)};
    }
    const rows=a.groupStandings('A',results);
    assert.equal(rows.filter(r=>r.status==='qualified').length,2);
    assert.equal(rows.filter(r=>r.status==='out').length,2);
    assert.equal(rows.reduce((n,r)=>n+r.sw,0),5);
    assert.equal(rows.reduce((n,r)=>n+r.sl,0),5);
    assert.equal(rows.reduce((n,r)=>n+r.mw-r.ml,0),0);
    assert.ok(rows.filter(r=>r.status==='qualified').every(r=>r.sw===2));
    assert.ok(rows.filter(r=>r.status==='out').every(r=>r.sl===2));
  }
});

test('playoff results obey Bo5 finals and are cleared when a first-round participant changes', () => {
  const a=engine();completeGroups(a);
  const q=plain(a.allQualified());
  q.forEach((t,i)=>a.state.po.assign['U'+(Math.floor(i/2)+1)+(i%2?'b':'a')]=t);
  for(const m of a.PO){
    const teams=a.poTeams(m.id,q);
    assert.ok(teams.every(Boolean),m.id);
    a.state.po.results[m.id]={w:teams[0],s:[(m.bo+1)/2,0],teams:plain(teams)};
  }
  assert.ok(a.poOutcome('GF',q));
  a.state.po.results.GF.s=[2,0];assert.equal(a.poOutcome('GF',q),null);
  a.state.po.assign.U1a=q[2];a.state.po.assign.U2a=q[0];
  assert.ok(a.reconcileState()>1);
  assert.equal(a.state.po.results.U1,undefined);
  assert.equal(a.state.po.results.GF,undefined);
});

test('malformed and legacy storage is normalized, deduplicated and migrated', () => {
  const a=engine({tab:'missing',picks:{adv:{A:['100T','100T','PRX','T1','FUT']},champ:'__proto__'},po:null,channel:'https://evil.invalid',watchSecs:-5});
  assert.equal(a.state.tab,'schedule');assert.equal(a.state.channel,'valorant');
  assert.deepEqual(plain(a.state.picks.adv.A),['100T','T1']);assert.equal(a.state.picks.champ,'');
  assert.deepEqual(plain(a.state.po),{assign:{},results:{}});
  assert.equal(a.state.watchSecs,0);
  assert.doesNotThrow(()=>a.normalizeState({results:[],picks:{adv:'broken'},live:null,filters:3}));
  const legacy=engine({results:{'A-O1':{w:'T1',s:[2,1]}}});
  assert.deepEqual(plain(legacy.state.manual['A-O1']),['100T','T1']);
});

test('backup round trip retains selections, overrides and preferences; invalid files are rejected', () => {
  const a=engine();a.state.picks.adv.A=['100T','FUT'];a.state.favorites=['PRX'];a.state.timezone='Asia/Shanghai';
  a.setGroupResult('A-W',['100T','FUT'],{w:'FUT',s:[2,1]});
  const restored=a.parseBackup(JSON.stringify(a.backupPayload()));
  assert.deepEqual(plain(restored),plain(a.state));
  for(const input of ['null','[]','{','{}',JSON.stringify({app:'other',version:1,state:{}}),' '.repeat(262145)])
    assert.throws(()=>a.parseBackup(input));
});

test('a past scheduled start never asserts LIVE, and stale API states expire', () => {
  const a=engine(),m=a.allMatches().find(m=>m.id==='A-W');
  assert.equal(a.matchStatus(m),'overdue');
  Object.assign(a.sync,{on:true,status:'ok',lastMs:Date.now(),apiState:{'A-W':'inProgress'},apiTeams:{'A-W':['100T','FUT']}});
  assert.equal(a.matchStatus(m),'live');
  a.sync.lastMs=Date.now()-121000;assert.equal(a.matchStatus(m),'overdue');
  a.sync.lastMs=Date.now();a.sync.apiTeams['A-W']=['T1','FUT'];assert.equal(a.matchStatus(m),'overdue');
});

test('feed normalization rejects bad scores, unknown states, outside dates and fuzzy team names', () => {
  const a=engine();
  const raw={startTime:'2026-09-30T12:00:00Z',state:'completed',match:{teams:[{code:'100T',result:{gameWins:2}},{code:'FUT',result:{gameWins:1}}]}};
  assert.equal(a.normEvent(raw).codes[0],'100T');
  for(const wins of [[1,0],[2,2],[2,-1],[2,0.5],[3,1]]){
    const r=plain(raw);r.match.teams.forEach((t,i)=>t.result.gameWins=wins[i]);assert.equal(a.normEvent(r),null);
  }
  assert.equal(a.normEvent({...raw,state:'postponed'}),null);
  assert.equal(a.normEvent({...raw,state:'constructor'}),null);
  const missing=plain(raw);delete missing.match.teams[1].result;
  assert.equal(a.normEvent(missing),null);
  assert.equal(a.normEvent({...raw,startTime:'2026-11-01T00:00:00Z'}),null);
  const fuzzy=plain(raw);fuzzy.match.teams[0]={name:'100 Thieves Academy',result:{gameWins:2}};
  assert.equal(a.normEvent(fuzzy),null);
});

test('sync respects manual final scores, manual map scores and cleared overrides', () => {
  const a=engine(),teams=['100T','FUT'],e=event(teams,[0,2]);
  a.setGroupResult('A-W',teams,{w:'100T',s:[2,1]});a.applyEvents([e]);
  assert.equal(a.state.results['A-W'].w,'100T');
  a.setGroupResult('A-W',teams,null);a.applyEvents([e]);assert.equal(a.state.results['A-W'],undefined);
  a.state.live['A-W']={teams,s:[1,0],source:'manual'};a.applyEvents([event(teams,[0,1],'inProgress')]);
  assert.deepEqual(plain(a.liveScore(a.allMatches().find(m=>m.id==='A-W'))),[1,0]);
  delete a.state.manual['A-W'];a.applyEvents([e]);assert.equal(a.state.results['A-W'].w,'FUT');
  assert.equal(a.state.results['A-W'].source,'riot');
});

test('sync handles reversed team order, duplicate responses and corrections', () => {
  const a=engine();
  const r=a.applyEvents([event(['FUT','100T'],[2,1]),event(['100T','FUT'],[1,1],'inProgress')]);
  assert.equal(r.matched,1);assert.equal(a.state.results['A-W'].w,'FUT');
  assert.equal(r.apiState['A-W'],'completed');
  a.applyEvents([event(['100T','FUT'],[2,0])]);assert.equal(a.state.results['A-W'].w,'100T');
  assert.equal(a.state.manual['A-W'],undefined);
});

test('schedule filters combine search, group, status and followed teams', () => {
  const a=engine();a.state.filters.query='paper rex';
  assert.ok(a.filteredMatches().length>0);assert.ok(a.filteredMatches().every(m=>m.teams.includes('PRX')));
  a.state.filters.group='A';assert.equal(a.filteredMatches().length,0);
  a.state.filters={query:'',group:'all',status:'upcoming',favorites:true};a.state.favorites=['TL'];
  assert.ok(a.filteredMatches().every(m=>m.teams.includes('TL') && !m.outcome));
});

test('calendar exports UTC starts, stable UIDs and folded lines; no completed or past events', () => {
  const a=engine();const calendar=a.buildCalendar(a.allMatches(),new Date('2026-09-30T00:00:00Z'));
  assert.match(calendar,/BEGIN:VCALENDAR\r\n/);assert.match(calendar,/DTSTART:20261001T090000Z/);
  assert.doesNotMatch(calendar,/UID:A-O1-/);assert.doesNotMatch(calendar,/UID:A-W-/);
  assert.equal((calendar.match(/BEGIN:VEVENT/g)||[]).length,8);
  assert.ok(calendar.split('\r\n').every(line=>Buffer.byteLength(line)<=75));
  assert.match(calendar,/STATUS:TENTATIVE/);assert.match(calendar,/DURATION:PT3H/);
  a.state.timezone='Asia/Shanghai';assert.equal(a.buildCalendar(a.allMatches(),new Date('2026-09-30T00:00:00Z')),calendar);
});

test('a stale unfinished response cannot erase a previously synced final', () => {
  const a=engine();
  a.applyEvents([event(['100T','FUT'],[2,1])]);
  a.applyEvents([event(['100T','FUT'],[0,0],'unstarted')]);
  a.applyEvents([event(['100T','FUT'],[1,0],'inProgress')]);
  assert.equal(a.state.results['A-W'].w,'100T');
  assert.deepEqual(plain(a.state.results['A-W'].s),[2,1]);
});

test('time zone grouping handles different dates and local-time formatting', () => {
  const a=engine(),d=new Date('2026-10-01T01:30:00Z');
  a.state.timezone='America/New_York';assert.equal(a.dayKey(d),'2026-09-30');
  a.state.timezone='Asia/Shanghai';assert.equal(a.dayKey(d),'2026-10-01');
  assert.equal(a.dayLabel(d),'Tomorrow');
});
